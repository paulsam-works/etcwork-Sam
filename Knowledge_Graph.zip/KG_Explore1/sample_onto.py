import os
import json
from typing import Annotated
import autogen
from ontogpt.engines.spires_engine import SPIRESEngine
from ontogpt.templates.disease import Disease

# 1. Define the SPIRES Extraction Tool
def extract_clinical_concepts(
    text: Annotated[str, "The unstructured clinical text to process"],
    template: Annotated[str, "The OntoGPT template name (e.g., 'disease', 'drug')"] = "disease"
) -> str:
    """
    Uses the SPIRES framework to extract clinical entities and ground them in ontologies.
    """
    try:
        # Initialize the SPIRES Engine with a standard template
        # templates like 'disease' are built-in to OntoGPT
        engine = SPIRESEngine(template=template)
        
        # Perform recursive extraction
        extraction_result = engine.extract_from_text(text)
        
        # Convert the extraction object to a readable JSON-like dictionary
        # This includes grounded IDs (e.g., MONDO:0005148)
        output = {
            "extracted_object": extraction_result.extracted_object,
            "named_entities": [
                {"id": ne.id, "label": ne.label} 
                for ne in extraction_result.named_entities
            ]
        }
        return json.dumps(output, indent=2)
    except Exception as e:
        return f"Error during extraction: {str(e)}"

# 2. Configure AutoGen Agents
config_list = [{"model": "gpt-4", "api_key": os.environ.get("OPENAI_API_KEY")}]

llm_config = {
    "config_list": config_list,
    "temperature": 0,
}

# The Knowledge Engineer: Uses tools to extract data
knowledge_engineer = autogen.AssistantAgent(
    name="Knowledge_Engineer",
    system_message="""You are a Knowledge Engineer specialized in Clinical Ontologies. 
    Your job is to take medical text and use the 'extract_clinical_concepts' tool to 
    turn it into structured, grounded data. Always report the final structured JSON.""",
    llm_config=llm_config,
)

# The Clinical Researcher: Provides input and validates the process
clinical_researcher = autogen.UserProxyAgent(
    name="Clinical_Researcher",
    human_input_mode="NEVER",
    max_consecutive_auto_reply=2,
    code_execution_config=False,
)

# 3. Register the Tool with AutoGen
autogen.agentchat.register_function(
    extract_clinical_concepts,
    caller=knowledge_engineer,
    executor=clinical_researcher,
    name="extract_clinical_concepts",
    description="Extracts structured clinical concepts using the SPIRES framework.",
)

# 4. Execute the Agentic Workflow
clinical_note = """
The patient is a 65-year-old male presenting with chronic hypertension 
and type 2 diabetes mellitus. He recently reported frequent migraines. 
Current medications include Lisinopril and Metformin.
"""

print("--- Starting Agentic Clinical Ontology Creation ---")
clinical_researcher.initiate_chat(
    knowledge_engineer,
    message=f"Please analyze this clinical note and extract the relevant diseases and medications into an ontology-grounded format: {clinical_note}"
)