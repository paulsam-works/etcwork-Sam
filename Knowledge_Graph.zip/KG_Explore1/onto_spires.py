import os
from autogen_agentchat.agents import AssistantAgent
from autogen_agentchat.ui import Console
from autogen_agentchat.teams import RoundRobinGroupChat
from autogen_ext.models.openai import OpenAIChatCompletionClient
from ontogpt.engines.spires_engine import SPIRESEngine
from typing import Annotated
import json
from dotenv import load_dotenv
from ontogpt.templates.disease import Disease

# 1. Define the SPIRES Tool
# 2. Configure the LLM Client (using GPT-5 or similar 2026 models)
def extract_clinical_concepts(
    text: Annotated[str, "The unstructured clinical text to process"],
    template: Annotated[str, "The OntoGPT template name (e.g., 'disease', 'drug')"] = "disease") -> str:
    """
    Uses the SPIRES framework to extract clinical entities and ground them in ontologies.
    """
    try:
        # Initialize the SPIRES Engine with a standard template
        # templates like 'disease' are built-in to OntoGPT
        engine = SPIRESEngine(template=template)
        
        # Perform recursive extraction
        extraction_result = engine.extract_from_text(text)
        
        # Convert the extraction object to a readable JSON-like dictionary
        # This includes grounded IDs (e.g., MONDO:0005148)
        output = {
            "extracted_object": extraction_result.extracted_object,
            "named_entities": [
                {"id": ne.id, "label": ne.label} 
                for ne in extraction_result.named_entities
            ]
        }
        return json.dumps(output, indent=2)
    except Exception as e:
        return f"Error during extraction: {str(e)}"

model_client = OpenAIChatCompletionClient(model="gpt-5", api_key=os.getenv("OPENAI_API_KEY"))

# 3. Create the Clinical Extraction Agent
clinical_agent = AssistantAgent(
    name="Clinical_Ontology_Agent",
    model_client=model_client,
    tools=[spires_clinical_extractor],
    system_message="You are a medical informatics expert. Use the spires_clinical_extractor "
                   "tool to process clinical notes and return grounded ontology data."
)

# 4. Run a sample extraction task
clinical_note = "Patient has cystic fibrosis and was treated with ivacaftor."

async def main():
    team = RoundRobinGroupChat([clinical_agent], max_turns=1)
    await Console(team.run_stream(task=f"Extract ontology from: {clinical_note}"))

import asyncio
asyncio.run(main())
