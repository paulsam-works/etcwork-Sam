def main():
    print("Hello from kg-explore!")


if __name__ == "__main__":
    main()
