import os
from autogen_agentchat.agents import AssistantAgent
from autogen_agentchat.ui import Console
from autogen_agentchat.teams import RoundRobinGroupChat
from autogen_ext.models.openai import OpenAIChatCompletionClient
from ontogpt.engines.spires_engine import SPIRESEngine
from dotenv import load_dotenv
load_dotenv()
openai_api_key = os.getenv("OPENAI_API_KEY")


# 1. Define the SPIRES Tool
def spires_clinical_extractor(text: str, schema_name: str = "disease") -> str:
    """
    Extracts clinical ontology data (e.g., diseases, symptoms) from text.
    Grounds entities to unique IDs (e.g., MONDO:0005044).
    """
    # Requires an OpenAI API key to be set in environment variables
    engine = SPIRESEngine(template=schema_name)
    results = engine.extract_from_text(text)
    
    # Return structured output as a string for the agent to process
    return str(results.extracted_object)

# 2. Configure the LLM Client (using GPT-5 or similar 2026 models)
model_client = OpenAIChatCompletionClient(model="gpt-5", api_key=os.getenv("OPENAI_API_KEY"))

# 3. Create the Clinical Extraction Agent
clinical_agent = AssistantAgent(
    name="Clinical_Ontology_Agent",
    model_client=model_client,
    tools=[spires_clinical_extractor],
    system_message="You are a medical informatics expert. Use the spires_clinical_extractor "
                   "tool to process clinical notes and return grounded ontology data."
)

# 4. Run a sample extraction task
clinical_note = "Patient has cystic fibrosis and was treated with ivacaftor."

async def main():
    team = RoundRobinGroupChat([clinical_agent], max_turns=1)
    await Console(team.run_stream(task=f"Extract ontology from: {clinical_note}"))

import asyncio
asyncio.run(main())
