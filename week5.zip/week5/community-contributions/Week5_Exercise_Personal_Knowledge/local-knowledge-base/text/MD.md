Zephyr won ZMD award
