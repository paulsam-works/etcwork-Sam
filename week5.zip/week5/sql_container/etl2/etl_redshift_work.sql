-- ============================================================================
-- AMAZON REDSHIFT COMPLEX ETL WORKFLOW
-- ============================================================================
SET timezone TO 'UTC';

-- STEP 1: BRONZE LAYER
TRUNCATE TABLE {{schemas.bronze}}.{{tables.stg_orders}};
COPY {{schemas.bronze}}.{{tables.stg_orders}} 
FROM '{{aws.s3_base_path}}/transactions/orders/' 
IAM_ROLE '{{aws.iam_role_arn}}' FORMAT AS PARQUET;

TRUNCATE TABLE {{schemas.bronze}}.{{tables.stg_order_items}};
COPY {{schemas.bronze}}.{{tables.stg_order_items}} 
FROM '{{aws.s3_base_path}}/transactions/order_items/' 
IAM_ROLE '{{aws.iam_role_arn}}' FORMAT AS PARQUET;

TRUNCATE TABLE {{schemas.bronze}}.{{tables.stg_customers_raw}};
COPY {{schemas.bronze}}.{{tables.stg_customers_raw}}
FROM '{{aws.s3_base_path}}/crm/customers_dump.csv' 
IAM_ROLE '{{aws.iam_role_arn}}' CSV DELIMITER ',' IGNOREHEADER 1;

TRUNCATE TABLE {{schemas.bronze}}.{{tables.stg_products_nested}};
COPY {{schemas.bronze}}.{{tables.stg_products_nested}}
FROM '{{aws.s3_base_path}}/pim/products_nested.json' 
IAM_ROLE '{{aws.iam_role_arn}}' JSON 'auto';

TRUNCATE TABLE {{schemas.bronze}}.{{tables.stg_web_clickstream}};
COPY {{schemas.bronze}}.{{tables.stg_web_clickstream}}
FROM '{{aws.s3_base_path}}/logs/web_server_logs.json.gz' 
IAM_ROLE '{{aws.iam_role_arn}}' JSON 'auto' GZIP;

-- STEP 2: SILVER LAYER
TRUNCATE TABLE {{schemas.silver}}.{{tables.customers_master}};
INSERT INTO {{schemas.silver}}.{{tables.customers_master}} (customer_id, email, cleaned_phone, city, country, ingestion_dt)
WITH ranked_customers AS (
    SELECT 
        customer_id, email,
        COALESCE(NULLIF(phone, ''), 'N/A') AS cleaned_phone,
        SPLIT_PART(full_address_messy, ',', 2) AS city_extract,
        SPLIT_PART(full_address_messy, ',', 3) AS country_extract,
        ROW_NUMBER() OVER (PARTITION BY email ORDER BY updated_at DESC) as rn 
    FROM {{schemas.bronze}}.{{tables.stg_customers_raw}}
)
SELECT CAST(customer_id AS INT), email, cleaned_phone, TRIM(city_extract), TRIM(country_extract), GETDATE()
FROM ranked_customers WHERE rn = 1;

-- STEP 3: GOLD LAYER (Join with Aliases)
TRUNCATE TABLE {{schemas.gold}}.{{tables.fact_sales_transactions}};
INSERT INTO {{schemas.gold}}.{{tables.fact_sales_transactions}} (order_id, date_key, customer_sk, product_sk, quantity, sales_amount)
SELECT 
    oe.order_id,
    CAST(TO_CHAR(oe.order_date, 'YYYYMMDD') AS INT) AS date_key,
    COALESCE(dc.customer_sk, -1) AS customer_sk, 
    COALESCE(dp.product_sk, -1) AS product_sk,
    oe.quantity,
    oe.gross_sales_line_total
FROM {{schemas.silver}}.{{tables.orders_enriched}} AS oe
LEFT JOIN {{schemas.gold}}.{{tables.dim_customer_scd2}} AS dc 
    ON oe.customer_id = dc.customer_id AND dc.is_current = TRUE
LEFT JOIN {{schemas.gold}}.{{tables.dim_product}} AS dp 
    ON oe.product_id = dp.product_id;

-- STEP 4: Aggregation
TRUNCATE TABLE {{schemas.gold}}.{{tables.agg_regional_daily}};
INSERT INTO {{schemas.gold}}.{{tables.agg_regional_daily}}
SELECT 
    ard.order_date,
    ard.region,
    SUM(ard.sales_amount) as total_sales
FROM {{schemas.gold}}.{{tables.fact_sales_transactions}} AS ard
GROUP BY 1, 2;

END TRANSACTION;