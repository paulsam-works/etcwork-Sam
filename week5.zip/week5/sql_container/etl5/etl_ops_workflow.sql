-- ============================================================================
-- AMAZON REDSHIFT ETL WORKFLOW - IT OPERATIONS DOMAIN
-- ============================================================================
-- Domain: IT Infrastructure & Application Monitoring
-- Flow: S3 Raw -> Bronze Staging -> Silver Cleaned -> Gold Star Schema
-- ============================================================================

SET timezone TO 'UTC';

-- ============================================================================
-- STEP 1: BRONZE LAYER - Ingest raw data from S3 various formats
-- ============================================================================

-- 1a. Load messy CSV Server Inventory (Hostnames, IPs, Locations)
-- (Reuses CSV loading technique)
TRUNCATE TABLE {{schemas.bronze}}.{{tables.stg_srv_inv}};
COPY {{schemas.bronze}}.{{tables.stg_srv_inv}}
FROM '{{aws.s3_base_path}}/inventory/server_list_dump.csv'
IAM_ROLE '{{aws.iam_role_arn}}' CSV DELIMITER ',' IGNOREHEADER 1 NULL AS 'NA';

-- 1b. Load Nested JSON Application Deployments
-- (Reuses Nested JSON 'auto' technique)
TRUNCATE TABLE {{schemas.bronze}}.{{tables.stg_app_dep}};
COPY {{schemas.bronze}}.{{tables.stg_app_dep}}
FROM '{{aws.s3_base_path}}/deployments/app_versions.json'
IAM_ROLE '{{aws.iam_role_arn}}' JSON 'auto';

-- 1c. Load Parquet Server Metrics (CPU/Mem utilization over time)
-- (Reuses Parquet loading technique)
TRUNCATE TABLE {{schemas.bronze}}.{{tables.stg_metrics}};
COPY {{schemas.bronze}}.{{tables.stg_metrics}}
FROM '{{aws.s3_base_path}}/metrics/server_utilization/'
IAM_ROLE '{{aws.iam_role_arn}}' FORMAT AS PARQUET;

-- 1d. Load Gzipped JSON Application Error Logs
-- (Reuses Gzipped JSON technique)
TRUNCATE TABLE {{schemas.bronze}}.{{tables.stg_logs}};
COPY {{schemas.bronze}}.{{tables.stg_logs}}
FROM '{{aws.s3_base_path}}/logs/app_errors.json.gz'
IAM_ROLE '{{aws.iam_role_arn}}' JSON 'auto' GZIP;


-- ============================================================================
-- STEP 2: SILVER LAYER - Clean, Conform, and Aggregate
-- ============================================================================

-- --- 2a. Silver Servers (Dedupe and split location data) ---
TRUNCATE TABLE {{schemas.silver}}.server_inventory_cleaned;

INSERT INTO {{schemas.silver}}.server_inventory_cleaned (hostname, cleaned_ip, os_platform, data_center, rack_id, ingestion_dt)
WITH ranked_servers AS (
    SELECT
        LOWER(TRIM(hostname)) as hostname_clean,
        -- Simple check to ensure IP looks vaguely valid, else null
        CASE WHEN ip_address ~ '^[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}$' THEN ip_address ELSE NULL END AS cleaned_ip,
        os_name AS os_platform,
        -- Split "US-East-DC1:Rack45" into discrete columns
        SPLIT_PART(location_string, ':', 1) AS data_center,
        SPLIT_PART(location_string, ':', 2) AS rack_id,
        -- Take latest scan if duplicate hostnames exist
        ROW_NUMBER() OVER (PARTITION BY LOWER(TRIM(hostname)) ORDER BY scan_timestamp DESC) as rn
    FROM {{schemas.bronze}}.{{tables.stg_srv_inv}}
    WHERE hostname IS NOT NULL
)
SELECT
    hostname_clean, cleaned_ip, os_platform, data_center, rack_id, GETDATE()
FROM ranked_servers WHERE rn = 1;


-- --- 2b. Silver Daily Metrics (Aggregating high-volume Parquet data) ---
TRUNCATE TABLE {{schemas.silver}}.daily_server_utilization;

INSERT INTO {{schemas.silver}}.daily_server_utilization
SELECT
    CAST(metric_timestamp AS DATE) as metric_date,
    LOWER(hostname) as hostname,
    -- Calculate daily averages from raw high-frequency metrics
    AVG(cpu_usage_percent) AS avg_daily_cpu,
    MAX(cpu_usage_percent) AS peak_daily_cpu,
    AVG(memory_free_gb) AS avg_daily_mem_free,
    GETDATE()
FROM {{schemas.bronze}}.{{tables.stg_metrics}}
GROUP BY 1, 2;


-- --- 2c. Silver Error Incidents (Windowing/Grouping similar to sessionization) ---
-- Instead of user sessions, we group bursts of errors on a single host into an "Incident".
TRUNCATE TABLE {{schemas.silver}}.error_incidents_grouped;

INSERT INTO {{schemas.silver}}.error_incidents_grouped
WITH lagged_errors AS (
    SELECT
        log_id, hostname, app_name, error_msg, log_timestamp_utc,
        -- Get time of previous error on same host/app combination
        LAG(log_timestamp_utc, 1) OVER (PARTITION BY hostname, app_name ORDER BY log_timestamp_utc) AS prev_error_time
    FROM {{schemas.bronze}}.{{tables.stg_logs}}
    WHERE severity_level = 'ERROR'
),
incident_flags AS (
    SELECT *,
        -- Flag new incident if time since last error exceeds threshold
        CASE WHEN DATEDIFF(minute, prev_error_time, log_timestamp_utc) >= {{params.error_grouping_window_minutes}} THEN 1
             WHEN prev_error_time IS NULL THEN 1 ELSE 0 END AS is_new_incident
    FROM lagged_errors
),
incident_grouping AS (
    SELECT *,
        -- Generate Incident ID via running sum
        SUM(is_new_incident) OVER (PARTITION BY hostname, app_name ORDER BY log_timestamp_utc ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS incident_seq_id
    FROM incident_flags
)
SELECT
    hostname || '-' || app_name || '-' || CAST(incident_seq_id AS VARCHAR) AS unique_incident_id,
    hostname, app_name,
    MIN(log_timestamp_utc) AS incident_start_utc,
    MAX(log_timestamp_utc) AS incident_end_utc,
    COUNT(DISTINCT log_id) AS error_count_in_incident,
    -- Arbitrarily pick the first error message as the descriptor
    FIRST_VALUE(error_msg) OVER (PARTITION BY hostname, app_name, incident_seq_id ORDER BY log_timestamp_utc ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) as primary_error_msg,
    GETDATE()
FROM incident_grouping
GROUP BY 1, 2, 3, incident_seq_id, error_msg, log_timestamp_utc;


-- ============================================================================
-- STEP 3: GOLD LAYER - Dimensional Modeling
-- ============================================================================

-- --- 3a. Dim Application (SCD Type 1 - Simple Overwrite) ---
-- Sourcing from nested JSON that was flattened.
BEGIN TRANSACTION;

CREATE TEMP TABLE tmp_dim_app (LIKE {{schemas.gold}}.dim_application);

-- Extract distinct application names and latest versions from staging
INSERT INTO tmp_dim_app (app_sk, app_name, current_version, description)
SELECT
    ROW_NUMBER() OVER (ORDER BY app_name) + (SELECT COALESCE(MAX(app_sk),0) FROM {{schemas.gold}}.dim_application),
    app_name,
    latest_version,
    'Imported via ETL' -- Placeholder description
FROM (
    SELECT DISTINCT
         json_extract_path_text(deployment_data, 'application_name') as app_name,
         json_extract_path_text(deployment_data, 'version_tag') as latest_version
    FROM {{schemas.bronze}}.{{tables.stg_app_dep}}
) source_data
WHERE app_name NOT IN (SELECT app_name FROM {{schemas.gold}}.dim_application);

INSERT INTO {{schemas.gold}}.dim_application SELECT * FROM tmp_dim_app;
DROP TABLE tmp_dim_app;
END TRANSACTION;


-- --- 3b. Dim Server (SCD Type 2 - Historical Tracking of OS or Location Changes) ---
-- We need to track if a server's OS is upgraded or if it moves data centers.
BEGIN TRANSACTION;

-- 1. Identify changed records between Silver and currently active Gold records
CREATE TEMP TABLE tmp_changed_servers AS
SELECT
    s.hostname, s.os_platform, s.data_center, s.rack_id, -- New values
    d.server_sk AS existing_sk_to_expire                  -- Old SK
FROM {{schemas.silver}}.server_inventory_cleaned s
INNER JOIN {{schemas.gold}}.dim_server_scd2 d
    ON s.hostname = d.hostname
    AND d.is_current = TRUE
WHERE
    -- Check for changes in tracking attributes
    s.os_platform <> d.os_platform OR s.data_center <> d.data_center OR s.rack_id <> d.rack_id;

-- 2. Expire old records in Gold
UPDATE {{schemas.gold}}.dim_server_scd2
SET is_current = FALSE,
    end_date = GETDATE()::DATE - 1
FROM tmp_changed_servers tmp
WHERE {{schemas.gold}}.dim_server_scd2.server_sk = tmp.existing_sk_to_expire;

-- 3. Identify net-new servers
CREATE TEMP TABLE tmp_new_servers AS
SELECT s.*
FROM {{schemas.silver}}.server_inventory_cleaned s
LEFT JOIN {{schemas.gold}}.dim_server_scd2 d ON s.hostname = d.hostname
WHERE d.hostname IS NULL;

-- 4. Insert new versions and net-new records
INSERT INTO {{schemas.gold}}.dim_server_scd2 (server_sk, hostname, os_platform, data_center, rack_id, start_date, end_date, is_current)
WITH all_new_server_records AS (
    SELECT hostname, os_platform, data_center, rack_id FROM tmp_changed_servers
    UNION ALL
    SELECT hostname, os_platform, data_center, rack_id FROM tmp_new_servers
)
SELECT
    ROW_NUMBER() OVER (ORDER BY hostname) + (SELECT COALESCE(MAX(server_sk),0) FROM {{schemas.gold}}.dim_server_scd2),
    hostname, os_platform, data_center, rack_id,
    GETDATE()::DATE AS start_date,
    '{{params.future_date}}'::DATE AS end_date,
    TRUE AS is_current
FROM all_new_server_records;

DROP TABLE tmp_changed_servers;
DROP TABLE tmp_new_servers;
END TRANSACTION;


-- --- 3c. Fact Daily Server Performance (Joining Facts to Dimensions) ---
BEGIN TRANSACTION;
TRUNCATE TABLE {{schemas.gold}}.fact_server_daily_perf;

INSERT INTO {{schemas.gold}}.fact_server_daily_perf (date_key, server_sk, avg_cpu_pct, peak_cpu_pct, avg_mem_free_gb, is_high_load_day)
SELECT
    CAST(TO_CHAR(dsu.metric_date, 'YYYYMMDD') AS INT) AS date_key,
    -- Join to SCD2 dimension using both natural key (hostname) AND date to find the correct version of the server record at that time
    COALESCE(ds.server_sk, -1) AS server_sk,
    dsu.avg_daily_cpu,
    dsu.peak_daily_cpu,
    dsu.avg_daily_mem_free,
    -- Apply business logic flag based on parameter
    CASE WHEN dsu.avg_daily_cpu > {{params.high_cpu_threshold}} THEN TRUE ELSE FALSE END as is_high_load_day
FROM {{schemas.silver}}.daily_server_utilization dsu
LEFT JOIN {{schemas.gold}}.dim_server_scd2 ds
    ON dsu.hostname = ds.hostname
    -- IMPORTANT: SCD Type 2 lookup requires checking the date range
    AND dsu.metric_date BETWEEN ds.start_date AND ds.end_date;

END TRANSACTION;

-- --- 3d. Aggregation: Weekly Error Summary by Datacenter ---
TRUNCATE TABLE {{schemas.gold}}.agg_weekly_dc_errors;

INSERT INTO {{schemas.gold}}.agg_weekly_dc_errors
SELECT
    DATE_TRUNC('week', eig.incident_start_utc)::DATE as week_start_date,
    ds.data_center,
    COUNT(DISTINCT unique_incident_id) as total_incidents,
    SUM(error_count_in_incident) as total_error_logs
FROM {{schemas.silver}}.error_incidents_grouped eig
-- Join to current server dimension to get current location
LEFT JOIN {{schemas.gold}}.dim_server_scd2 ds
    ON eig.hostname = ds.hostname AND ds.is_current = TRUE
GROUP BY 1, 2;


VACUUM;
ANALYZE;