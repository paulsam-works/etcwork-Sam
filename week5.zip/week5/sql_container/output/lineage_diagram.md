%% =========================
%% BRONZE -> SILVER: CUSTOMERS_MASTER
%% =========================
subgraph BRONZE_STG_CUSTOMERS["bronze_staging.stg_customers_raw"]
B_CUST_ID["customer_id"]
B_EMAIL["email"]
B_PHONE["phone"]
B_ADDR["full_address_messy"]
end
subgraph SILVER_CUSTOMERS["silver_layer.customers_master"]
S_CUST_ID["customer_id"]
S_EMAIL["email"]
S_CLEANED_PHONE["cleaned_phone"]
S_CITY["city"]
S_COUNTRY["country"]
S_CUST_INGEST["ingestion_dt"]
end
B_CUST_ID -->|"CAST(customer_id AS INT)"| S_CUST_ID
B_EMAIL -->|"Direct Map (after dedupe)"| S_EMAIL
B_PHONE -->|"COALESCE(NULLIF(phone,''),'N/A')"| S_CLEANED_PHONE
B_ADDR -->|"TRIM(SPLIT_PART(...,',',2))"| S_CITY
B_ADDR -->|"TRIM(SPLIT_PART(...,',',3))"| S_COUNTRY
S_CUST_INGEST -->|"GETDATE()"| S_CUST_INGEST
%% =========================
%% BRONZE -> SILVER: PRODUCTS_CATALOG
%% =========================
subgraph BRONZE_STG_PRODUCTS["bronze_staging.stg_products_nested"]
B_PROD_ID["product_id"]
B_PROD_NAME["product_name"]
B_CAT["category"]
B_SPECS["specs (JSON)"]
end
subgraph SILVER_PRODUCTS["silver_layer.products_catalog"]
P_PROD_ID["product_id"]
P_PROD_NAME["product_name"]
P_STD_CAT["standardize_cat"]
P_UNIT_PRICE["unit_price"]
P_INGEST["ingestion_dt"]
end
B_PROD_ID -->|"Direct Map"| P_PROD_ID
B_PROD_NAME -->|"Direct Map"| P_PROD_NAME
B_CAT -->|"CASE … THEN 'Electronics - Mobile' / 'Uncategorized' / ELSE category"| P_STD_CAT
B_SPECS -->|"CAST(json_extract_path_text(specs,'price') AS DECIMAL(10,2))"| P_UNIT_PRICE
P_INGEST -->|"GETDATE()"| P_INGEST
%% =========================
%% BRONZE -> SILVER: ORDERS_ENRICHED
%% =========================
subgraph BRONZE_STG_ORDERS["bronze_staging.stg_orders"]
BO_ORD_ID["order_id"]
BO_CUST_ID["customer_id"]
BO_ORDER_DATE["order_date"]
end
subgraph BRONZE_STG_ORDER_ITEMS["bronze_staging.stg_order_items"]
BI_ORD_ID["order_id"]
BI_PROD_ID["product_id"]
BI_QTY["quantity"]
BI_UNIT_PRICE["unit_price"]
end
subgraph SILVER_ORD_ENRICHED["silver_layer.orders_enriched\n(o.customer_id > 100)"]
OE_ORD_ID["order_id"]
OE_CUST_ID["customer_id"]
OE_PROD_ID["product_id"]
OE_ORDER_DATE["order_date"]
OE_QTY["quantity"]
OE_UNIT_PRICE["unit_price"]
OE_GROSS["gross_sales_line_total"]
OE_INGEST["ingestion_dt"]
end
BO_ORD_ID -->|"Direct Map (JOIN o.order_id = oi.order_id)"| OE_ORD_ID
BO_CUST_ID -->|"Direct Map (filter > 100)"| OE_CUST_ID
BI_PROD_ID -->|"Direct Map"| OE_PROD_ID
BO_ORDER_DATE -->|"CAST(o.order_date AS DATE)"| OE_ORDER_DATE
BI_QTY -->|"Direct Map"| OE_QTY
BI_UNIT_PRICE -->|"Direct Map"| OE_UNIT_PRICE
BI_QTY -->|"quantity * unit_price"| OE_GROSS
BI_UNIT_PRICE -->|"quantity * unit_price"| OE_GROSS
OE_INGEST -->|"GETDATE()"| OE_INGEST
%% =========================
%% BRONZE -> SILVER: USER_SESSIONS
%% =========================
subgraph BRONZE_WEB["bronze_staging.stg_web_clickstream"]
W_COOKIE["cookie_id"]
W_TS["timestamp_utc"]
W_PAGE["page_url"]
end
subgraph SILVER_SESSIONS["silver_layer.user_sessions\n(sessionization)"]
US_UNIQ_ID["unique_session_id"]
US_COOKIE["cookie_id"]
US_START["session_start_utc"]
US_END["session_end_utc"]
US_PAGES["total_pages_viewed"]
US_DUR["session_duration_sec"]
US_INGEST["ingestion_dt"]
end
W_COOKIE -->|"cookie_id || '-' || session_seq_id"| US_UNIQ_ID
W_COOKIE -->|"GROUP BY"| US_COOKIE
W_TS -->|"MIN(timestamp_utc)"| US_START
W_TS -->|"MAX(timestamp_utc)"| US_END
W_PAGE -->|"COUNT(DISTINCT page_url)"| US_PAGES
W_TS -->|"DATEDIFF(second, MIN(ts), MAX(ts))"| US_DUR
US_INGEST -->|"GETDATE()"| US_INGEST
%% =========================
%% SILVER -> GOLD: DIM_PRODUCT (via tmp_dim_product)
%% =========================
subgraph TMP_DIM_PRODUCT["tmp_dim_product (temp)"]
T_DP_SK["product_sk"]
T_DP_ID["product_id"]
T_DP_NAME["product_name"]
T_DP_CAT["category"]
T_DP_PRICE["current_price"]
end
subgraph GOLD_DIM_PRODUCT["gold_layer.dim_product"]
G_DP_SK["product_sk"]
G_DP_ID["product_id"]
G_DP_NAME["product_name"]
G_DP_CAT["category"]
G_DP_PRICE["current_price"]
end
P_PROD_ID -->|"ROW_NUMBER() OVER (ORDER BY product_id) + MAX(product_sk)"| T_DP_SK
P_PROD_ID -->|"Direct Map"| T_DP_ID
P_PROD_NAME -->|"Direct Map"| T_DP_NAME
P_STD_CAT -->|"Direct Map"| T_DP_CAT
P_UNIT_PRICE -->|"Direct Map"| T_DP_PRICE
T_DP_SK -->|"Direct Load"| G_DP_SK
T_DP_ID -->|"Direct Load"| G_DP_ID
T_DP_NAME -->|"Direct Load"| G_DP_NAME
T_DP_CAT -->|"Direct Load"| G_DP_CAT
T_DP_PRICE -->|"Direct Load"| G_DP_PRICE
%% =========================
%% SILVER -> GOLD: DIM_CUSTOMER_SCD2
%% =========================
subgraph TMP_CHANGED["tmp_changed_customers (temp)"]
TC_ID["customer_id"]
TC_EMAIL["email"]
TC_CITY["city"]
TC_COUNTRY["country"]
TC_OLD_SK["existing_sk_to_expire"]
end
subgraph TMP_NEW["tmp_new_customers (temp)"]
TN_ALL["customers_master."]
end
subgraph GOLD_DIM_CUSTOMER["gold_layer.dim_customer_scd2 (SCD2)"]
G_DC_SK["customer_sk"]
G_DC_ID["customer_id"]
G_DC_EMAIL["email"]
G_DC_CITY["city"]
G_DC_COUNTRY["country"]
G_DC_START["start_date"]
G_DC_END["end_date"]
G_DC_CURR["is_current"]
end
CUST_Master_ID[CUSTOMERS_MASTER.customer_id]:::hidden
CUST_Master_EMAIL[CUSTOMERS_MASTER.email]:::hidden
CUST_Master_CITY[CUSTOMERS_MASTER.city]:::hidden
CUST_Master_COUNTRY[CUSTOMERS_MASTER.country]:::hidden
classDef hidden display:none;
CUST_Master_ID -->|"Direct Map"| TC_ID
CUST_Master_EMAIL -->|"Direct Map"| TC_EMAIL
CUST_Master_CITY -->|"Direct Map"| TC_CITY
CUST_Master_COUNTRY -->|"Direct Map"| TC_COUNTRY
TC_OLD_SK -->|"expire old rows (is_current=FALSE, end_date=GETDATE()-1)"| G_DC_SK
TN_ALL -->|"Direct Load from customers_master."| G_DC_ID
TC_ID -->|"ROW_NUMBER() OVER (ORDER BY customer_id) + MAX(customer_sk)"| G_DC_SK
TC_ID -->|"Direct Map"| G_DC_ID
TC_EMAIL -->|"Direct Map"| G_DC_EMAIL
TC_CITY -->|"Direct Map"| G_DC_CITY
TC_COUNTRY -->|"Direct Map"| G_DC_COUNTRY
G_DC_START -->|"GETDATE()::DATE"| G_DC_START
G_DC_END -->|"'9999-12-31'::DATE"| G_DC_END
G_DC_CURR -->|"TRUE"| G_DC_CURR
%% =========================
%% SILVER + GOLD -> FACT_SALES_TRANSACTIONS
%% =========================
subgraph GOLD_FACT["gold_layer.fact_sales_transactions"]
F_ORDER_ID["order_id"]
F_DATE_KEY["date_key"]
F_CUST_SK["customer_sk"]
F_PROD_SK["product_sk"]
F_QTY["quantity"]
F_SALES["sales_amount"]
end
OE_ORD_ID -->|"Direct Map"| F_ORDER_ID
OE_ORDER_DATE -->|"CAST(TO_CHAR(order_date,'YYYYMMDD') AS INT)"| F_DATE_KEY
OE_QTY -->|"Direct Map"| F_QTY
OE_GROSS -->|"Direct Map"| F_SALES
G_DC_SK -->|"COALESCE(dc.customer_sk,-1)"| F_CUST_SK
G_DP_SK -->|"COALESCE(dp.product_sk,-1)"| F_PROD_SK
%% =========================
%% SILVER -> GOLD: AGG_REGIONAL_DAILY
%% =========================
subgraph GOLD_AGG["gold_layer.agg_regional_daily"]
A_DATE["order_date"]
A_COUNTRY["country_code_simulated"]
A_ORDERS["total_orders"]
A_SALES["total_sales"]
end
OE_ORDER_DATE -->|"GROUP BY; Direct Map"| A_DATE
A_COUNTRY -->|"'USA'"| A_COUNTRY
OE_ORD_ID -->|"COUNT(DISTINCT order_id)"| A_ORDERS
OE_GROSS -->|"SUM(gross_sales_line_total)"| A_SALES