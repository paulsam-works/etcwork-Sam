-- Silver Layer: Cleansing and Master Data Enrichment
\set ON_ERROR_STOP on

BEGIN;

-- Target Table: silver.enriched_transactions
-- Logic: Join Sales with CRM and Exchange Rates
DELETE FROM silver.enriched_transactions WHERE region = :v_region_code;

INSERT INTO silver.enriched_transactions
SELECT 
    s.txn_id,
    s.cust_id,
    c.lead_source,
    s.amount * COALESCE(xr.rate, 1.0) as amount_standardized,
    :v_currency_base as currency
FROM bronze.sales_transactions s
LEFT JOIN bronze.crm_leads c ON s.cust_id = c.cust_id
INNER JOIN ref.exchange_rates xr ON s.currency = xr.src_currency
WHERE s.amount > :v_min_threshold
AND xr.is_active = 1;

-- Target Table: silver.customer_master
TRUNCATE TABLE silver.customer_master;
INSERT INTO silver.customer_master
SELECT cust_id, UPPER(cust_name), email_address 
FROM bronze.crm_leads
WHERE email_address LIKE '%@%';

COMMIT;