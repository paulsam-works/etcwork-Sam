-- Gold Layer: Fact and Dimension Construction
\set ON_ERROR_STOP on

BEGIN;

-- 1. Update Product Dimension
MERGE INTO gold.dim_products p
USING silver.enriched_transactions s ON p.sku_id = s.prod_id
WHEN MATCHED THEN UPDATE SET last_seen = GETDATE()
WHEN NOT MATCHED THEN INSERT (sku_id, created_at) VALUES (s.prod_id, GETDATE());

-- 2. Build Sales Fact Table
-- Sources: silver.enriched_transactions, silver.customer_master, gold.dim_products
TRUNCATE TABLE gold.fact_monthly_sales;

INSERT INTO gold.fact_monthly_sales
SELECT 
    d.product_key,
    cm.cust_id,
    SUM(et.amount_standardized) as total_revenue,
    COUNT(et.txn_id) as volume,
    :v_fiscal_year as fiscal_year
FROM silver.enriched_transactions et
JOIN silver.customer_master cm ON et.cust_id = cm.cust_id
JOIN gold.dim_products d ON et.prod_id = d.sku_id
GROUP BY 1, 2;

COMMIT;
ANALYZE gold.fact_monthly_sales;