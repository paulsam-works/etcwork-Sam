-- Bronze Layer: Ingestion from S3
\set ON_ERROR_STOP on
\echo 'Starting Parallel Ingestion for ' :v_region_code

BEGIN;

-- 1. Ingest Sales Transactions
CREATE TEMP TABLE stg_sales_raw (LIKE bronze.sales_transactions);
COPY stg_sales_raw FROM :v_path_sales IAM_ROLE :v_iam_role FORMAT AS PARQUET;

DELETE FROM bronze.sales_transactions WHERE txn_id IN (SELECT txn_id FROM stg_sales_raw);
INSERT INTO bronze.sales_transactions SELECT *, GETDATE() FROM stg_sales_raw;

-- 2. Ingest CRM Leads
CREATE TEMP TABLE stg_crm_raw (LIKE bronze.crm_leads);
COPY stg_crm_raw FROM :v_path_crm IAM_ROLE :v_iam_role FORMAT AS CSV IGNOREHEADER 1;

TRUNCATE TABLE bronze.crm_leads;
INSERT INTO bronze.crm_leads SELECT * FROM stg_crm_raw;

COMMIT;